import React from 'react'

function Login() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <h1 className='text-2xl font-bold text-center mt-10'>Login Page</h1>
    </div>
  )
}

export default Login
